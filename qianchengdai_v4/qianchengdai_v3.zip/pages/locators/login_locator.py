#!/usr/bin/env python3
#-*- coding:utf-8 -*-
# author:muji
# datetime:2019/5/8 21:58

# username_locator = (By)

from selenium import webdriver

driver = webdriver.Chrome()